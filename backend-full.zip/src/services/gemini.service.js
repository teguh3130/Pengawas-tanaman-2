'use strict';

/**
 * gemini.service.js
 * Wrapper Google Gemini API untuk analisis kebutuhan tanaman.
 *
 * API Key HANYA diambil dari process.env.GEMINI_API_KEY (backend .env).
 * Tidak pernah dikirim ke frontend atau ESP32.
 */

const { GoogleGenerativeAI } = require('@google/generative-ai');

let genAI  = null;
let model  = null;

/**
 * Inisialisasi Gemini client.
 * Dipanggil lazy (saat pertama kali dibutuhkan).
 */
function initGemini() {
  if (model) return;

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'your_gemini_api_key_here') {
    throw new Error('GEMINI_API_KEY belum dikonfigurasi di .env');
  }

  genAI = new GoogleGenerativeAI(apiKey);
  model = genAI.getGenerativeModel({
    model: process.env.GEMINI_MODEL || 'gemini-1.5-flash',
    generationConfig: {
      responseMimeType: 'application/json',
      temperature     : 0.3,  // Lebih deterministik untuk data ilmiah
    },
  });

  console.log(`✅ Gemini AI siap (model: ${process.env.GEMINI_MODEL || 'gemini-1.5-flash'})`);
}

/**
 * Minta Gemini menganalisis kebutuhan tanaman dan mengembalikan
 * parameter pemantauan dalam format JSON terstruktur.
 *
 * @param {object} plantData - { name, type, variety, location, additionalInfo }
 * @returns {Promise<object>} requirements yang sudah diparse
 */
async function generatePlantRequirements(plantData) {
  initGemini();

  const { name, type, variety = '-', location = '-', additionalInfo = '-' } = plantData;

  const prompt = `
Kamu adalah ahli pertanian dan hortikultura. Analisis kebutuhan tanaman berikut dan berikan rekomendasi parameter pemantauan yang akurat berdasarkan pengetahuan ilmiah.

Tanaman  : ${name}
Jenis    : ${type}
Varietas : ${variety}
Lokasi   : ${location}
Catatan  : ${additionalInfo}

PENTING:
- Berikan nilai berdasarkan literatur ilmiah atau panduan budidaya yang umum digunakan.
- Bedakan antara nilai ideal (terbaik) dan nilai toleransi/warning (batas aman).
- Jika data spesifik tidak tersedia, berikan estimasi umum untuk jenis tanaman tersebut dan tandai di disclaimer.
- Jangan mengarang nilai yang tidak memiliki dasar ilmiah.
- Nilai soilMoisture adalah persentase (0-100%), bukan nilai ADC.

Berikan respons HANYA dalam format JSON berikut, tanpa teks atau markdown di luar JSON:

{
  "soilMoisture": {
    "ideal":   { "min": <number 0-100>, "max": <number 0-100> },
    "warning": { "min": <number 0-100>, "max": <number 0-100> },
    "unit": "%",
    "note": "<penjelasan singkat kebutuhan kelembapan tanah>"
  },
  "temperature": {
    "ideal":   { "min": <number>, "max": <number> },
    "warning": { "min": <number>, "max": <number> },
    "unit": "°C",
    "note": "<penjelasan singkat kebutuhan suhu>"
  },
  "airHumidity": {
    "ideal":   { "min": <number 0-100>, "max": <number 0-100> },
    "warning": { "min": <number 0-100>, "max": <number 0-100> },
    "unit": "%",
    "note": "<penjelasan singkat kebutuhan kelembapan udara>"
  },
  "light": {
    "ideal":   { "minLux": <number>, "maxLux": <number> },
    "warning": { "minLux": <number>, "maxLux": <number> },
    "dailyDurationHours": <number 0-24>,
    "unit": "lux",
    "note": "<penjelasan singkat kebutuhan cahaya>"
  },
  "watering": {
    "frequency": "<seberapa sering penyiraman dianjurkan>",
    "method"   : "<cara penyiraman yang dianjurkan>"
  },
  "pumpAuto": {
    "triggerMoistureMin": <number — ambang batas mulai pompa, sama atau lebih rendah dari soilMoisture.warning.min>,
    "targetMoistureMax" : <number — target kelembapan saat pompa berhenti, sama atau lebih rendah dari soilMoisture.ideal.max>
  },
  "warnings": [
    "<kondisi yang perlu diwaspadai 1>",
    "<kondisi yang perlu diwaspadai 2>"
  ],
  "description": "<penjelasan singkat 2-3 kalimat tentang kebutuhan umum tanaman ini>",
  "source"     : "<dasar atau referensi rekomendasi jika tersedia, atau 'Estimasi umum berbasis panduan budidaya'>",
  "disclaimer" : "<catatan jika ada nilai yang perlu diverifikasi lebih lanjut>"
}
`.trim();

  const result   = await model.generateContent(prompt);
  const rawText  = result.response.text().trim();

  // Parsing JSON — Gemini dengan responseMimeType JSON seharusnya langsung valid
  let parsed;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    // Fallback: coba ekstrak JSON dari dalam code block markdown
    const match = rawText.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) {
      try {
        parsed = JSON.parse(match[1].trim());
      } catch (e2) {
        throw new Error(`Gagal memparsing respons Gemini sebagai JSON: ${e2.message}\nRaw: ${rawText.slice(0, 200)}`);
      }
    } else {
      throw new Error(`Respons Gemini bukan JSON valid.\nRaw: ${rawText.slice(0, 200)}`);
    }
  }

  return parsed;
}

/**
 * Minta Gemini menganalisis kondisi kesehatan tanaman berdasarkan data sensor aktual
 * dan parameter kebutuhan tanaman yang sudah dikonfigurasi.
 *
 * @param {object} payload - { plant, requirements, sensorData, actualEvaluation }
 * @returns {Promise<object>} hasil analisis kesehatan + rekomendasi penanganan spesifik
 */
async function generatePlantHealthAnalysis({ plant, requirements, sensorData, actualEvaluation }) {
  initGemini();

  const prompt = `
Kamu adalah agronom dan ahli kesehatan tanaman berbasis data sensor IoT.
Analisis kondisi kesehatan tanaman berikut secara objektif HANYA berdasarkan data sensor aktual dan ambang batas kebutuhan tanaman yang diberikan.

PROFIL TANAMAN:
- Nama      : ${plant?.name || '-'}
- Jenis     : ${plant?.type || '-'}
- Varietas  : ${plant?.variety || '-'}
- Lokasi    : ${plant?.location || '-'}
- Catatan   : ${plant?.additionalInfo || '-'}

DATA SENSOR AKTUAL SAAT INI:
- Kelembapan Tanah : ${sensorData.soilMoisture}%
- Suhu Udara       : ${sensorData.temperature}°C
- Kelembapan Udara : ${sensorData.airHumidity}%
- Intensitas Cahaya: ${sensorData.lightLux} lux
- Sumber Data      : ${sensorData.source || 'SENSOR'}

AMBANG BATAS KEBUTUHAN TANAMAN:
- Kelembapan Tanah Ideal: ${requirements?.soilMoisture?.ideal?.min ?? '-'}–${requirements?.soilMoisture?.ideal?.max ?? '-'}% (Waspada: ${requirements?.soilMoisture?.warning?.min ?? '-'}–${requirements?.soilMoisture?.warning?.max ?? '-'}%)
- Suhu Udara Ideal      : ${requirements?.temperature?.ideal?.min ?? '-'}–${requirements?.temperature?.ideal?.max ?? '-'}°C (Waspada: ${requirements?.temperature?.warning?.min ?? '-'}–${requirements?.temperature?.warning?.max ?? '-'}%)
- Kelembapan Udara Ideal: ${requirements?.airHumidity?.ideal?.min ?? '-'}–${requirements?.airHumidity?.ideal?.max ?? '-'}% (Waspada: ${requirements?.airHumidity?.warning?.min ?? '-'}–${requirements?.airHumidity?.warning?.max ?? '-'}%)
- Cahaya Ideal          : ${requirements?.light?.ideal?.minLux ?? '-'}–${requirements?.light?.ideal?.maxLux ?? '-'} lux

EVALUASI NUMERIK AKTUAL SISTEM:
${JSON.stringify(actualEvaluation, null, 2)}

ATURAN KETAT:
1. Status kesehatan HARUS salah satu dari tepat 3 nilai: "Sehat", "Kurang Sehat", atau "Tidak Sehat".
2. JANGAN mengarang data sensor yang tidak ada atau bertentangan dengan angka di atas.
3. Jika evaluasi numerik menunjukkan ada parameter "bahaya" (di luar batas aman), status TIDAK BOLEH "Sehat".
4. Rekomendasi penanganan HARUS spesifik untuk jenis tanaman "${plant?.type || plant?.name}" dan kondisi angka sensor aktual di atas (bukan saran generik).
5. Jika semua parameter normal/ideal, tetap berikan langkah pemeliharaan preventif yang relevan dengan karakteristik tanaman tersebut dengan prioritas "Rendah".

Berikan respons HANYA dalam format JSON berikut tanpa teks lain:
{
  "status": "Sehat" | "Kurang Sehat" | "Tidak Sehat",
  "confidence": <integer 0-100>,
  "reason": "<penjelasan ringkas 2-3 kalimat mengenai alasan penilaian berdasarkan angka sensor aktual>",
  "problematicParameters": [
    {
      "parameter": "soilMoisture" | "temperature" | "airHumidity" | "lightLux",
      "label": "<nama parameter bahasa Indonesia>",
      "severity": "waspada" | "bahaya",
      "issue": "<penjelasan spesifik dampak penyimpangan angka terhadap tanaman ini>"
    }
  ],
  "recommendations": [
    {
      "issueCondition": "<kondisi spesifik yang perlu diperbaiki atau dipertahankan>",
      "actionTitle": "<judul tindakan singkat & jelas>",
      "steps": [
        "<langkah praktis 1 cara melakukan penanganan>",
        "<langkah praktis 2 cara melakukan penanganan>"
      ],
      "priority": "Tinggi" | "Sedang" | "Rendah",
      "targetParameter": "soilMoisture" | "temperature" | "airHumidity" | "lightLux" | "general"
    }
  ],
  "disclaimer": "<catatan singkat batas analisis sensor tanpa inspeksi visual daun/akar>"
}
`.trim();

  const result = await model.generateContent(prompt);
  const rawText = result.response.text().trim();

  let parsed;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    const match = rawText.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) {
      parsed = JSON.parse(match[1].trim());
    } else {
      throw new Error(`Respons Gemini analisis kesehatan bukan JSON valid.`);
    }
  }

  return parsed;
}

module.exports = { generatePlantRequirements, generatePlantHealthAnalysis };

